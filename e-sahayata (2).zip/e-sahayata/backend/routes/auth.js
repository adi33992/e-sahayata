const express = require("express");
const router = express.Router();

// Very simple demo login route to connect frontend to backend.
// In a real app, you would verify the user from the database.
router.post("/login", (req, res) => {
    const { email, password } = req.body || {};

    if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
    }

    // Demo: accept any non-empty email/password and return a mock user
    const user = {
        id: 1,
        email,
        name: "Demo Citizen"
    };

    return res.json({ user });
});

module.exports = router;
