const express = require("express");
const router = express.Router();
const db = require("../db");

// POST incident
router.post("/", (req, res) => {
    const { title, description, location } = req.body;

    const sql = "INSERT INTO incidents (title, description, location) VALUES (?, ?, ?)";
    db.query(sql, [title, description, location], (err, result) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ message: "Incident saved!" });
    });
});

// GET all incidents
router.get("/", (req, res) => {
    const sql = "SELECT * FROM incidents ORDER BY created_at DESC";

    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);
    });
});

module.exports = router;
