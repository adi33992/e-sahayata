const el = (id) => document.getElementById(id);
const state = { map: null, marker: null, reports: [], photos: [], hasMedia: false };
function getSession(){ try { return JSON.parse(localStorage.getItem('civic_session')||'null'); } catch(e){ return null; } }

(function(){
  const s = getSession();
  if(!s){ window.location.href = 'Index.html'; return; }
  const w = el('welcomeText');
  if(w){
    const name = (s.name && s.name.trim()) || s.identifier || 'citizen';
    w.textContent = 'Welcome back, ' + name;
  }
})();

function getPublic(){ try { return JSON.parse(localStorage.getItem('civic_public')||'[]'); } catch(e){ return [] } }
function setPublic(arr){ localStorage.setItem('civic_public', JSON.stringify(arr)); }
function getVotes(){ try { return JSON.parse(localStorage.getItem('civic_votes')||'{}'); } catch(e){ return {} } }
function setVotes(obj){ localStorage.setItem('civic_votes', JSON.stringify(obj)); }
function getDeviceId(){ let id = localStorage.getItem('civic_device'); if(!id){ id = (crypto.randomUUID?crypto.randomUUID():String(Math.random()).slice(2)); localStorage.setItem('civic_device', id); } return id; }
function getUsers(){ try { return JSON.parse(localStorage.getItem('civic_users')||'[]'); } catch(e){ return [] } }
function getAssignments(){ try { return JSON.parse(localStorage.getItem('civic_assignment')||'{}'); } catch(e){ return {} } }
function nameByUserId(id){ if(!id) return '—'; const u = getUsers().find(x=>x.id===id); return (u && (u.name||u.identifier)) || '—'; }
function now(){ return Date.now(); }
function updateCounts(){ const mc = el('myCount'); const pc = el('pubCount'); if(mc) mc.textContent = String(getReports().length); if(pc) pc.textContent = String(getPublic().length); }

function base64ToBuf(b64){ const bin = atob(b64); const len = bin.length; const bytes = new Uint8Array(len); for (let i=0;i<len;i++) bytes[i]=bin.charCodeAt(i); return bytes.buffer; }

async function deriveKey(pass,salt){
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey('raw', enc.encode(pass), {name:'PBKDF2'}, false, ['deriveKey']);
  return await crypto.subtle.deriveKey({name:'PBKDF2', hash:'SHA-256', salt, iterations:150000}, baseKey, {name:'AES-GCM', length:256}, false, ['encrypt','decrypt']);
}
async function decryptJSON(payload, pass){
  const salt = new Uint8Array(base64ToBuf(payload.salt));
  const iv = new Uint8Array(base64ToBuf(payload.iv));
  const key = await deriveKey(pass, salt);
  const pt = await crypto.subtle.decrypt({name:'AES-GCM', iv}, key, base64ToBuf(payload.ct));
  return JSON.parse(new TextDecoder().decode(pt));
}

function categoryWeight(cat){
  const map = { 'Public Safety':30, 'Health':25, 'Infrastructure':20, 'Water':22, 'Sanitation':18, 'Environment':15, 'Traffic':15, 'Other':5 };
  return map[cat]||10;
}
function recencyScore(ts){
  const hours = Math.max(0, (now()-ts)/36e5);
  const v = Math.round(30*Math.exp(-hours/72));
  return v;
}
function priorityScore(r){
  const sev = Number(r.severity||3);
  const cw = categoryWeight(r.category);
  const rc = recencyScore(r.ts);
  const media = r.hasMedia ? 5 : 0;
  const unresolved = r.status==='pending' ? 5 : 0;
  let score = sev*12 + cw + rc + media + unresolved;
  if (score>100) score = Math.min(100, Math.round(80 + (score-80)*0.5));
  return Math.max(0, Math.min(100, Math.round(score)));
}

function updateScorePreview(){
  const r = { category: el('category').value, severity: el('severity').value, ts: now(), hasMedia: state.photos.length>0, status: 'pending' };
  el('scorePreview').textContent = String(priorityScore(r));
}

function severityPill(sev){
  const s = Number(sev)||1;
  const map = {
    1:{bg:'rgba(148,163,184,.15)',fg:'#cbd5e1',bd:'rgba(148,163,184,.35)'},
    2:{bg:'rgba(234,179,8,.12)',fg:'#fde68a',bd:'rgba(234,179,8,.35)'},
    3:{bg:'rgba(249,115,22,.12)',fg:'#fdba74',bd:'rgba(249,115,22,.35)'},
    4:{bg:'rgba(239,68,68,.12)',fg:'#fca5a5',bd:'rgba(239,68,68,.35)'},
    5:{bg:'rgba(190,18,60,.12)',fg:'#fecaca',bd:'rgba(190,18,60,.35)'}
  };
  const c = map[s] || map[1];
  return `<span class="pill" style="background:${c.bg};color:${c.fg};border-color:${c.bd}">Severity ${s}</span>`;
}

function toggle(section){
  const sRep = el('reportSection');
  const sList = el('listSection');
  const sPub = el('publicSection');
  const tRep = el('tabReport');
  const tList = el('tabList');
  const tPub = el('tabPublic');
  if(!sPub) return;
  sRep.classList.toggle('hidden', section!== 'report');
  sList.classList.toggle('hidden', section!== 'list');
  sPub.classList.toggle('hidden', section!== 'public');
  tRep.classList.toggle('active', section==='report');
  tList.classList.toggle('active', section==='list');
  tPub.classList.toggle('active', section==='public');
  if(section==='list') renderList();
  if(section==='public') renderFeed();
}

function ensureMap(){
  if(state.map) return;
  el('map').classList.remove('hidden');
  const lat = parseFloat(el('lat').value)||20.5937; const lng = parseFloat(el('lng').value)||78.9629;
  state.map = L.map('map').setView([lat,lng], (lat===20.5937?5:15));
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution:'&copy; OpenStreetMap' }).addTo(state.map);
  state.marker = L.marker([lat,lng], {draggable:true}).addTo(state.map);
  state.marker.on('dragend', ()=>{
    const p = state.marker.getLatLng(); el('lat').value = p.lat.toFixed(6); el('lng').value = p.lng.toFixed(6);
  });
}

function setMarker(lat,lng){ ensureMap(); state.map.setView([lat,lng], 16); state.marker.setLatLng([lat,lng]); el('lat').value = lat.toFixed(6); el('lng').value = lng.toFixed(6); }

function dataURLFromImage(img, maxSize){
  const canvas = document.createElement('canvas');
  let w = img.naturalWidth, h = img.naturalHeight; const m = maxSize;
  if(w>h && w>m){ h = Math.round(h*(m/w)); w=m } else if(h>m){ w = Math.round(w*(m/h)); h=m }
  canvas.width=w; canvas.height=h; const ctx = canvas.getContext('2d'); ctx.drawImage(img,0,0,w,h);
  return canvas.toDataURL('image/jpeg', 0.7);
}

async function compressFileToDataURL(file){
  return new Promise((resolve,reject)=>{
    const fr = new FileReader();
    fr.onload = ()=>{ const img = new Image(); img.onload=()=>{ try { resolve(dataURLFromImage(img,1280)); } catch(e){ reject(e) } }; img.onerror=reject; img.src = fr.result; };
    fr.onerror = reject; fr.readAsDataURL(file);
  });
}

function clearForm(){ el('title').value=''; el('description').value=''; el('photo').value=''; el('photoPreview').innerHTML=''; state.photos=[]; state.hasMedia=false; el('anonymous').checked=false; el('contactEmail').value=''; el('contactPhone').value=''; const ln = el('locationNote'); if(ln) ln.value=''; }

function renderPhotoPreview(){
  const root = el('photoPreview'); root.innerHTML='';
  state.photos.forEach((d,i)=>{
    const wrap = document.createElement('div'); wrap.className='thumb-wrap';
    const im = new Image(); im.src=d; im.className='thumb';
    const rm = document.createElement('button'); rm.type='button'; rm.className='thumb-remove'; rm.textContent='×';
    rm.addEventListener('click', ()=>{ state.photos.splice(i,1); state.hasMedia = state.photos.length>0; renderPhotoPreview(); updateScorePreview(); });
    wrap.appendChild(im); wrap.appendChild(rm); root.appendChild(wrap);
  });
}

async function saveReport(){
  const title = el('title').value.trim();
  const category = el('category').value;
  const severity = Number(el('severity').value);
  const description = el('description').value.trim();
  const anonymous = el('anonymous').checked;
  const contact = anonymous? {} : { email: el('contactEmail').value.trim(), phone: el('contactPhone').value.trim() };
  const lat = parseFloat(el('lat').value)||null; const lng = parseFloat(el('lng').value)||null;
  const locationNote = (el('locationNote') && el('locationNote').value) ? el('locationNote').value.trim() : '';
  if(title.length < 3){ alert('Please enter a longer title (min 3 characters).'); return; }
  const ts = now();
  const assignedTo = (getAssignments()[category]) || undefined;
  const base = { id: (crypto.randomUUID?crypto.randomUUID():String(ts)), ts, category, severity, status:'pending', location: lat&&lng?{lat,lng}:null, anonymous, encrypted:false, hasMedia: state.photos.length>0, assignedTo, assignedAt: assignedTo?ts:undefined };
  const details = { title, description, locationNote, photos: state.photos, contact };
  const toSave = { ...base, details };
  const arr = getReports();
  arr.unshift(toSave);
  setReports(arr);
  updateCounts();
  clearForm(); updateScorePreview();
  el('submitMsg').classList.remove('hidden'); setTimeout(()=>el('submitMsg').classList.add('hidden'), 1500);
}

function renderList(){
  state.reports = getReports();
  const fc = el('filterCategory').value; const fs = el('filterStatus').value; const q = el('searchText').value.toLowerCase(); const sort = el('sortBy').value;
  let items = state.reports.map(r=> ({...r, score: priorityScore(r)}));
  if(fc) items = items.filter(r=>r.category===fc);
  if(fs) items = items.filter(r=>r.status===fs);
  if(q){
    items = items.filter(r=>{
      if(!r.encrypted && r.details){ const s = (r.details.title||'')+' '+(r.details.description||''); return s.toLowerCase().includes(q); }
      return false;
    });
  }
  if(sort==='new') items.sort((a,b)=>b.ts-a.ts); else if(sort==='severity') items.sort((a,b)=>b.severity-a.severity); else items.sort((a,b)=>b.score-a.score);
  const root = el('list'); root.innerHTML='';
  for(const r of items){
    const wrap = document.createElement('div'); wrap.className='item';
    const h = document.createElement('h4'); h.textContent = (!r.encrypted && r.details && r.details.title) ? r.details.title : (r.category+" • "+new Date(r.ts).toLocaleString());
    const m = document.createElement('div'); m.className='meta'; m.innerHTML = `<span>${r.category}</span>${severityPill(r.severity)}<span>${new Date(r.ts).toLocaleString()}</span><span class="pill ${r.status==='pending'?'pill-pending':'pill-resolved'}">${r.status}</span><span>Assignee ${nameByUserId(r.assignedTo)}</span><span class="score">Score ${r.score}</span>`;
    const body = document.createElement('div'); body.style.marginTop='6px';
    if(!r.encrypted && r.details){
      const p = document.createElement('p'); p.style.fontSize='13px'; p.style.color='#cbd5e1'; p.textContent = r.details.description||''; body.appendChild(p);
      if(r.details.locationNote){ const loc=document.createElement('p'); loc.style.fontSize='12px'; loc.style.color='#9ca3af'; loc.textContent='Location: '+r.details.locationNote; body.appendChild(loc); }
      if(r.details.photos && r.details.photos.length){ const pv=document.createElement('div'); pv.className='preview'; for(const d of r.details.photos){ const im=new Image(); im.src=d; im.className='thumb'; pv.appendChild(im);} body.appendChild(pv); }
    } else {
      const p = document.createElement('p'); p.className='muted'; p.textContent='Encrypted details'; body.appendChild(p);
    }
    const actions = document.createElement('div'); actions.className='inline'; actions.style.marginTop='8px';
    const btnResolve = document.createElement('button'); btnResolve.textContent = r.status==='pending'?'Mark resolved':'Mark pending'; btnResolve.addEventListener('click',()=>{ r.status = r.status==='pending'?'resolved':'pending'; const all=getReports(); const idx=all.findIndex(x=>x.id===r.id); if(idx>-1){ all[idx].status=r.status; setReports(all); renderList(); } });
    actions.appendChild(btnResolve);
    if(r.location){ const btnMap=document.createElement('button'); btnMap.className='ghost'; btnMap.textContent='View map'; btnMap.addEventListener('click',()=>{ const lat=r.location.lat, lng=r.location.lng; const url='https://www.openstreetmap.org/?mlat='+lat+'&mlon='+lng+'#map=16/'+lat+'/'+lng; window.open(url,'_blank'); }); actions.appendChild(btnMap); }
    if(r.encrypted){ const btnDec=document.createElement('button'); btnDec.className='ghost'; btnDec.textContent='Decrypt'; btnDec.addEventListener('click', async()=>{ const pass = prompt('Passphrase'); if(!pass) return; try{ const d=await decryptJSON(r.payload, pass); body.innerHTML=''; const p=document.createElement('p'); p.style.fontSize='13px'; p.style.color='#cbd5e1'; p.textContent=d.description||''; body.appendChild(p); if(d.photos&&d.photos.length){ const pv=document.createElement('div'); pv.className='preview'; for(const s of d.photos){ const im=new Image(); im.src=s; im.className='thumb'; pv.appendChild(im);} body.appendChild(pv);} h.textContent = d.title || h.textContent; } catch(e){ alert('Decryption failed'); } }); actions.appendChild(btnDec); }
    if(!r.encrypted){
      const pubAll = getPublic();
      const isPublished = pubAll.some(p => (p.sourceId||p.id) === r.id);
      const btnPub = document.createElement('button');
      btnPub.className = 'ghost';
      btnPub.textContent = isPublished ? 'Unpublish' : 'Publish';
      btnPub.addEventListener('click', ()=>{
        let feed = getPublic();
        if(isPublished){
          feed = feed.filter(p => (p.sourceId||p.id) !== r.id);
          setPublic(feed); renderList(); if(!el('publicSection').classList.contains('hidden')) renderFeed(); updateCounts();
        } else {
          const details = r.details || {};
          const item = { id: r.id, sourceId: r.id, ts: r.ts, category: r.category, severity: r.severity, status: r.status, location: r.location||null, hasMedia: r.hasMedia, title: details.title||'', description: details.description||'', locationNote: details.locationNote||'', photos: details.photos||[], votes: 0 };
          const ids = new Set(feed.map(p=>p.sourceId||p.id));
          if(!ids.has(item.sourceId)){ feed.unshift(item); setPublic(feed); renderList(); if(!el('publicSection').classList.contains('hidden')) renderFeed(); updateCounts(); }
        }
      });
      actions.appendChild(btnPub);
    }
    const btnDel = document.createElement('button'); btnDel.className='ghost'; btnDel.textContent='Delete'; btnDel.addEventListener('click',()=>{ if(!confirm('Delete this report?')) return; const all=getReports().filter(x=>x.id!==r.id); setReports(all); const feed=getPublic().filter(p=>(p.sourceId||p.id)!==r.id); setPublic(feed); renderList(); if(!el('publicSection').classList.contains('hidden')) renderFeed(); updateCounts(); }); actions.appendChild(btnDel);
    wrap.appendChild(h); wrap.appendChild(m); wrap.appendChild(body); wrap.appendChild(actions);
    root.appendChild(wrap);
  }
}

function renderFeed(){
  let items = getPublic().slice();
  const fc = el('feedFilterCategory').value; const sort = el('feedSortBy').value; const q = el('feedSearchText').value.toLowerCase();
  if(fc) items = items.filter(r=>r.category===fc);
  if(q) items = items.filter(r=>(((r.title||'')+' '+(r.description||'')+' '+(r.locationNote||'')).toLowerCase().includes(q)));
  if(sort==='new') items.sort((a,b)=>b.ts-a.ts); else if(sort==='score') items.sort((a,b)=>priorityScore(b)-priorityScore(a)); else items.sort((a,b)=>(b.votes||0)-(a.votes||0));
  const root = el('feedList'); root.innerHTML=''; const votedMap = getVotes();
  for(const r of items){
    const wrap = document.createElement('div'); wrap.className='item';
    const h = document.createElement('h4'); h.textContent = (r.title && r.title.trim()) ? r.title : (r.category+" • "+new Date(r.ts).toLocaleString());
    const m = document.createElement('div'); m.className='meta'; m.innerHTML = `<span>${r.category}</span>${severityPill(r.severity)}<span>${new Date(r.ts).toLocaleString()}</span><span class="score">Score ${priorityScore(r)}</span><span>Votes ${(r.votes||0)}</span>`;
    const body = document.createElement('div'); body.style.marginTop='6px';
    if(r.description){ const p=document.createElement('p'); p.style.fontSize='13px'; p.style.color='#cbd5e1'; p.textContent=r.description; body.appendChild(p); }
    if(r.locationNote){ const loc=document.createElement('p'); loc.style.fontSize='12px'; loc.style.color='#9ca3af'; loc.textContent='Location: '+r.locationNote; body.appendChild(loc); }
    if(r.photos && r.photos.length){ const pv=document.createElement('div'); pv.className='preview'; for(const s of r.photos){ const im=new Image(); im.src=s; im.className='thumb'; pv.appendChild(im);} body.appendChild(pv); }
    const actions = document.createElement('div'); actions.className='inline'; actions.style.marginTop='8px';
    if(r.location){ const btnMap=document.createElement('button'); btnMap.className='ghost'; btnMap.textContent='View map'; btnMap.addEventListener('click',()=>{ const lat=r.location.lat, lng=r.location.lng; const url='https://www.openstreetmap.org/?mlat='+lat+'&mlon='+lng+'#map=16/'+lat+'/'+lng; window.open(url,'_blank'); }); actions.appendChild(btnMap); }
    const btnVote = document.createElement('button'); btnVote.textContent = votedMap[r.id] ? 'Voted' : 'Vote'; if(votedMap[r.id]) btnVote.disabled = true;
    btnVote.addEventListener('click', ()=>{
      const votes = getVotes(); if(votes[r.id]){ alert('You already voted for this'); return; }
      votes[r.id] = now(); setVotes(votes);
      const pub = getPublic(); const idx = pub.findIndex(p=>p.id===r.id); if(idx>-1){ pub[idx].votes = (pub[idx].votes||0)+1; setPublic(pub); }
      renderFeed();
    });
    actions.appendChild(btnVote);
    wrap.appendChild(h); wrap.appendChild(m); wrap.appendChild(body); wrap.appendChild(actions);
    root.appendChild(wrap);
  }
}

// Event wiring
el('tabReport').addEventListener('click', ()=>toggle('report'));
el('tabList').addEventListener('click', ()=>toggle('list'));
el('tabPublic').addEventListener('click', ()=>toggle('public'));
el('logoutBtn').addEventListener('click', ()=>{ try{ localStorage.removeItem('civic_session'); }catch(e){} window.location.href = 'Index.html'; });

el('severity').addEventListener('input', ()=>{ el('sevVal').textContent = el('severity').value; updateScorePreview(); });
el('category').addEventListener('change', updateScorePreview);

el('anonymous').addEventListener('change', ()=>{ el('contactFields').classList.toggle('hidden', el('anonymous').checked); });

el('initMapBtn').addEventListener('click', ensureMap);
el('locateBtn').addEventListener('click', ()=>{
  navigator.geolocation.getCurrentPosition(pos=>{ const {latitude, longitude} = pos.coords; setMarker(latitude, longitude); }, err=>{ ensureMap(); alert('Location unavailable'); }, {enableHighAccuracy:true, timeout:8000});
});

el('photo').addEventListener('change', async (e)=>{
  state.photos=[]; state.hasMedia=false; el('photoPreview').innerHTML='';
  const files = Array.from(e.target.files||[]).slice(0,4);
  if(!files.length) return;
  try{ const urls = await Promise.all(files.map(f=>compressFileToDataURL(f))); state.photos = urls; state.hasMedia = urls.length>0; renderPhotoPreview(); updateScorePreview(); }
  catch(err){ alert('Could not process photo(s)'); }
});

el('submitBtn').addEventListener('click', saveReport);

document.addEventListener('click', (ev)=>{
  if(ev.target && ev.target.id==='feedExportBtn'){
    const data = JSON.stringify(getPublic());
    const blob = new Blob([data], {type:'application/json'});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'civic_public_'+new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')+'.json'; a.click(); URL.revokeObjectURL(a.href);
  }
});
el('feedImportBtn') && el('feedImportBtn').addEventListener('click', ()=> el('feedImportFile').click());
el('feedImportFile') && el('feedImportFile').addEventListener('change', async (e)=>{
  const f = e.target.files && e.target.files[0]; if(!f) return; try{ const txt = await f.text(); const arr = JSON.parse(txt); if(!Array.isArray(arr)) throw new Error('invalid'); const existing = getPublic(); const ids = new Set(existing.map(r=>r.id)); const merged = [...arr.filter(r=>!ids.has(r.id)), ...existing]; setPublic(merged); renderFeed(); updateCounts(); alert('Imported'); } catch(err){ alert('Import failed'); }
  e.target.value='';
});

el('filterCategory').addEventListener('change', renderList);
el('filterStatus').addEventListener('change', renderList);
el('sortBy').addEventListener('change', renderList);
el('searchText').addEventListener('input', ()=>{ clearTimeout(state._t); state._t = setTimeout(renderList, 200); });
el('feedFilterCategory').addEventListener('change', renderFeed);
el('feedSortBy').addEventListener('change', renderFeed);
el('feedSearchText').addEventListener('input', ()=>{ clearTimeout(state._t2); state._t2 = setTimeout(renderFeed, 200); });

updateScorePreview();
updateCounts();
